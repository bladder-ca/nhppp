test_that("vztdraw_sc_step_regular() works", {
  # 1 row matrix
  expect_no_error(Z0 <- vztdraw_sc_step_regular(
    Lambda_matrix = matrix(1:5, nrow = 1),
    range_t = c(100, 110),
    atmost1 = FALSE
  ))

  Z0 <- Z0[1, !is.na(Z0[1, ])]
  if (length(Z0) > 0) {
    check_ppp_sample_validity(Z0, t_min = 100, t_max = 110, atleast1 = TRUE)
  }

  l <- matrix(rep(1, 50), ncol = 5)
  L <- mat_cumsum_columns(l)

  expect_no_error(Z <- vztdraw_sc_step_regular(
    Lambda_matrix = L,
    range_t = c(100, 110),
    atmost1 = FALSE
  ))

  for (i in 1:nrow(Z)) {
    tmp <- Z[i, !is.na(Z[i, ])]
    if (length(tmp) > 0) {
      check_ppp_sample_validity(tmp, t_min = 100, t_max = 110, atleast1 = TRUE)
    }
  }
  expect_no_error(Z1 <- vztdraw_sc_step_regular(
    Lambda_matrix = L,
    range_t = c(100, 110),
    atmost1 = TRUE
  ))
  for (i in 1:nrow(Z1)) {
    tmp <- Z1[i, !is.na(Z1[i, ])]
    if (length(tmp) > 0) {
      check_ppp_sample_validity(tmp, t_min = 100, t_max = 110, atmost1 = TRUE, atleast1 = TRUE)
    }
  }
  expect_no_error(Z2 <- vztdraw_sc_step_regular(
    lambda_matrix = l,
    range_t = c(100, 110),
    atmost1 = TRUE
  ))
  for (i in 1:nrow(Z2)) {
    tmp <- Z2[i, !is.na(Z2[i, ])]
    if (length(tmp) > 0) {
      check_ppp_sample_validity(tmp, t_min = 100, t_max = 110, atmost1 = TRUE, atleast1 = TRUE)
    }
  }
  # very small rates
  expect_no_error(Z2 <- vztdraw_sc_step_regular(
    lambda_matrix = l * 0.001,
    range_t = c(100, 110),
    atmost1 = TRUE
  ))
  for (i in 1:nrow(Z2)) {
    tmp <- Z2[i, !is.na(Z2[i, ])]
    if (length(tmp) > 0) {
      check_ppp_sample_validity(tmp, t_min = 100, t_max = 110, atmost1 = TRUE, atleast1 = TRUE)
    }
  }
})

test_that("vztdraw_sc_step_regular() does not break with matrices whose mode is list", {
  l <- matrix(rep(1, 50), ncol = 5)
  L <- mat_cumsum_columns(l)

  mode(L) <- "list"
  expect_no_error(Z <- vztdraw_sc_step_regular(
    Lambda_matrix = L,
    range_t = c(100, 110),
    atmost1 = FALSE
  ))
})
