# nhppp 0.1.3

# nhppp 0.1.2

* Renamed functions to start from `draw` (instead of `nhppp_t`), `draw_zt` (instead of `ztnhppp_t`), and `vdraw` (instead of ending in `_vec()`) 

* Initial CRAN submission.

